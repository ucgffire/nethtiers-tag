package com.noland.tiertagger.mixin;

import com.noland.tiertagger.cache.TierCache;
import com.noland.tiertagger.config.ModConfig;
import com.noland.tiertagger.util.TierFormatter;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.UUID;

@Mixin(PlayerListHud.class)
public class PlayerListHudMixin {

    @ModifyVariable(method = "getPlayerName", at = @At("HEAD"), argsOnly = true)
    private Text noland$addTierToTab(Text original, PlayerListEntry entry) {
        ModConfig config = ModConfig.get();
        if (!config.enabled || !config.showTab) return original;

        UUID uuid = entry.getProfile().getId();
        String name = entry.getProfile().getName();
        if (name == null) return original;

        TierCache.registerPlayer(uuid, name);

        return TierCache.getByUuid(uuid)
                .flatMap(data -> TierFormatter.buildTierPrefix(data, config))
                .<Text>map(prefix -> Text.empty().append(prefix).append(Text.literal(" ")).append(original))
                .orElse(original);
    }
}
