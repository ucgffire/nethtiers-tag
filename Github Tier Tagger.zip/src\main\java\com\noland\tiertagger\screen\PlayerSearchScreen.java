package com.noland.tiertagger.screen;

import com.mojang.authlib.GameProfile;
import com.noland.tiertagger.cache.TierCache;
import com.noland.tiertagger.model.PlayerTierData;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class PlayerSearchScreen extends Screen {
    private final Screen parent;
    private final String initialQuery;

    private TextFieldWidget searchField;
    private ButtonWidget searchButton;
    private boolean searching = false;
    private CompletableFuture<?> pendingSearch;

    public PlayerSearchScreen(Screen parent, String initialQuery) {
        super(Text.translatable("noland.search.title"));
        this.parent = parent;
        this.initialQuery = initialQuery;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;

        this.searchField = new TextFieldWidget(this.textRenderer, centerX - 100, this.height / 2 - 30, 200, 20, Text.translatable("noland.search.placeholder"));
        this.searchField.setMaxLength(16);
        this.searchField.setTextPredicate(s -> s.matches("[a-zA-Z0-9_]*"));
        if (initialQuery != null) {
            this.searchField.setText(initialQuery);
        }
        this.addSelectableChild(this.searchField);
        this.setInitialFocus(this.searchField);

        this.searchButton = this.addDrawableChild(ButtonWidget.builder(Text.translatable("noland.search.button"), btn -> search())
                .dimensions(centerX - 100, this.height / 2, 200, 20)
                .build());

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.cancel"), btn -> close())
                .dimensions(centerX - 100, this.height / 2 + 28, 200, 20)
                .build());

        if (initialQuery != null && !initialQuery.isBlank()) {
            search();
        }
    }

    private void search() {
        String query = this.searchField.getText().trim();
        if (query.isEmpty() || searching) {
            return;
        }

        searching = true;
        this.searchButton.active = false;
        this.searchButton.setMessage(Text.translatable("noland.search.loading"));

        if (pendingSearch != null) {
            pendingSearch.cancel(true);
        }

        pendingSearch = TierCache.searchPlayer(query).thenAccept(result -> this.client.execute(() -> {
            searching = false;
            this.searchButton.active = true;
            this.searchButton.setMessage(Text.translatable("noland.search.button"));

            if (result.isPresent()) {
                PlayerTierData data = result.get();
                GameProfile profile = new GameProfile(UUID.nameUUIDFromBytes(("OfflinePlayer:" + data.mcName()).getBytes()), data.mcName());
                this.client.setScreen(new PlayerProfileScreen(this.parent != null ? this.parent : this, data, profile));
            } else {
                this.searchButton.setMessage(Text.translatable("noland.search.not_found"));
            }
        }));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 60, 0xFFFFFF);
        this.searchField.render(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        if (pendingSearch != null) {
            pendingSearch.cancel(true);
        }
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) {
            search();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
