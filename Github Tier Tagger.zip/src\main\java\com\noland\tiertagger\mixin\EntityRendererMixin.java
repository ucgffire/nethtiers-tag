package com.noland.tiertagger.mixin;

import com.noland.tiertagger.cache.TierCache;
import com.noland.tiertagger.config.ModConfig;
import com.noland.tiertagger.util.TierFormatter;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.UUID;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin<T extends Entity> {

    @ModifyVariable(method = "renderLabelIfPresent", at = @At("HEAD"), argsOnly = true)
    private Text noland$addTierToLabel(Text original, T entity, Text text, net.minecraft.client.util.math.MatrixStack matrices, net.minecraft.client.render.VertexConsumerProvider vertexConsumers, int light) {
        if (!(entity instanceof PlayerEntity player)) return original;

        ModConfig config = ModConfig.get();
        if (!config.enabled || !config.showNametag) return original;

        UUID uuid = player.getUuid();
        String name = player.getName().getString();
        TierCache.registerPlayer(uuid, name);

        return TierCache.getByUuid(uuid)
                .flatMap(data -> TierFormatter.buildTierPrefix(data, config))
                .<Text>map(prefix -> Text.empty().append(prefix).append(Text.literal(" ")).append(original))
                .orElse(original);
    }
}
