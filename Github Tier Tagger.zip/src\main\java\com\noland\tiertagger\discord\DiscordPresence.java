package com.noland.tiertagger.discord;

import com.noland.tiertagger.NolandTierTaggerClient;
import net.minecraft.client.MinecraftClient;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class DiscordPresence {
    private static final String APPLICATION_ID = "1530062258644713594";
    private static final DiscordIpcClient client = new DiscordIpcClient();
    private static boolean initialized = false;
    private static long lastMessageChange = 0;
    private static String currentMessage = null;
    private static String lastServerName = null;
    private static String lastSentMessage = null;
    private static long sessionStartTime = 0;

    private static final List<String> MESSAGES = List.of(
        "Kılıcını Kuşandı",
        "Trap Basıyor..",
        "Ekonomiyi Eziyor",
        "Farm Yapıyor",
        "PvP Antrenmanı Yapıyor",
        "Elini Isındırıyor",
        "Savaşıyor",
        "Base Kuruyor",
        "Enchant Basıyor",
        "Demir Kazıyor",
        "Netherda Macera Arıyor",
        "Pot Farmı Yapıyor.",
        "Netherite Zırhını Giyiyor",
        "Mob Farmda Bekliyor",
        "Maden Kazıyor"
    );

    private DiscordPresence() {
    }

    public static void init() {
        if (initialized) return;
        initialized = true;
        sessionStartTime = System.currentTimeMillis() / 1000L;

        Thread discordThread = new Thread(() -> {
            try {
                Thread.sleep(3000L);
            } catch (InterruptedException e) {
                return;
            }

            NolandTierTaggerClient.LOGGER.info("Attempting Discord IPC connection...");
            boolean connected = client.connect(APPLICATION_ID);
            if (connected) {
                NolandTierTaggerClient.LOGGER.info("Discord Rich Presence connected successfully");
            } else {
                NolandTierTaggerClient.LOGGER.warn("Discord IPC connection failed - Discord may not be running");
            }
        }, "Discord IPC Init");
        discordThread.setDaemon(true);
        discordThread.start();
    }

    public static void updatePresence() {
        if (!client.isConnected()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        long now = System.currentTimeMillis();

        if (sessionStartTime == 0) {
            sessionStartTime = now / 1000L;
        }

        if (currentMessage == null || now - lastMessageChange >= 60000) {
            currentMessage = MESSAGES.get(ThreadLocalRandom.current().nextInt(MESSAGES.size()));
            lastMessageChange = now;
        }

        String serverName = "Minecraft";
        if (mc.getCurrentServerEntry() != null) {
            String ip = mc.getCurrentServerEntry().address;
            if (ip.contains("soyanetwork") || ip.contains("soya")) {
                serverName = "SoyaNetwork";
            } else {
                serverName = ip.contains(":") ? ip.split(":")[0] : ip;
            }
        }

        String sentKey = serverName + "|" + currentMessage;
        if (sentKey.equals(lastSentMessage)) return;
        lastSentMessage = sentKey;

        client.updateActivity(
                serverName,
                currentMessage,
                "noland_logo",
                "Noland Tier Tagger",
                sessionStartTime
        );
    }

    public static void clearPresence() {
        lastSentMessage = null;
        lastServerName = null;
        sessionStartTime = 0;
        client.clearActivity();
    }

    public static void shutdown() {
        client.disconnect();
    }
}
