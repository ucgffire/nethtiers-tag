package com.noland.tiertagger.api;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.noland.tiertagger.NolandTierTaggerClient;
import com.noland.tiertagger.model.PlayerTierData;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

public final class TierApiService {
    private static final String API_URL = "https://nethtiers.com/api/players";
    private static final Gson GSON = new Gson();
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    private TierApiService() {
    }

    public static CompletableFuture<List<PlayerTierData>> fetchAllPlayersAsync() {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(API_URL))
                .timeout(Duration.ofSeconds(30))
                .header("Accept", "application/json")
                .header("User-Agent", "NolandTierTagger/1.0")
                .GET()
                .build();

        return CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    if (response.statusCode() != 200) {
                        NolandTierTaggerClient.LOGGER.debug("API returned {} for player list", response.statusCode());
                        return List.<PlayerTierData>of();
                    }
                    return parsePlayerList(response.body());
                })
                .exceptionally(error -> {
                    NolandTierTaggerClient.LOGGER.debug("API error: {}", error.getMessage());
                    return List.of();
                });
    }

    static List<PlayerTierData> parsePlayerList(String body) {
        if (body == null || body.isBlank()) {
            return List.of();
        }

        try {
            JsonElement root = JsonParser.parseString(body);
            if (!root.isJsonArray()) {
                return List.of();
            }

            JsonArray array = root.getAsJsonArray();
            List<PlayerTierData> result = new ArrayList<>();
            for (JsonElement element : array) {
                if (element.isJsonObject()) {
                    PlayerTierData.fromJson(element.getAsJsonObject()).ifPresent(result::add);
                }
            }
            return result;
        } catch (Exception e) {
            NolandTierTaggerClient.LOGGER.debug("Failed to parse API response: {}", e.getMessage());
            return List.of();
        }
    }
}
