package com.noland.tiertagger;

import com.noland.tiertagger.cache.TierCache;
import com.noland.tiertagger.config.ModConfig;
import com.noland.tiertagger.discord.DiscordPresence;
import com.noland.tiertagger.screen.ConfigScreen;
import com.noland.tiertagger.screen.PlayerSearchScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NolandTierTaggerClient implements ClientModInitializer {
    public static final String MOD_ID = "noland-tier-tagger";
    public static final Logger LOGGER = LoggerFactory.getLogger("NolandTierTagger");

    private static KeyBinding settingsKey;
    private static KeyBinding searchKey;

    @Override
    public void onInitializeClient() {
        ModConfig.load();

        ResourceManagerHelper.registerBuiltinResourcePack(
                Identifier.of(MOD_ID, "noland-resources"),
                FabricLoader.getInstance().getModContainer(MOD_ID).orElseThrow(),
                Text.literal("Noland Tier Tagger Resources"),
                ResourcePackActivationType.ALWAYS_ENABLED
        );

        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "noland.key.settings",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                "key.category.noland"
        ));

        searchKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "noland.key.search",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                "key.category.noland"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (settingsKey.wasPressed()) {
                openSettings(client);
            }
            while (searchKey.wasPressed()) {
                openSearch(client);
            }

            if (client.player != null && client.world != null) {
                DiscordPresence.updatePresence();
            }
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            for (var entry : handler.getPlayerList()) {
                TierCache.registerPlayer(entry.getProfile().getId(), entry.getProfile().getName());
            }
            TierCache.refresh();
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            DiscordPresence.clearPresence();
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("nolandtiers")
                        .then(ClientCommandManager.literal("settings").executes(ctx -> {
                            MinecraftClient.getInstance().execute(() -> openSettings(MinecraftClient.getInstance()));
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("search")
                                .then(ClientCommandManager.argument("player", com.mojang.brigadier.arguments.StringArgumentType.string())
                                        .executes(ctx -> {
                                            String player = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "player");
                                            MinecraftClient.getInstance().execute(() ->
                                                    MinecraftClient.getInstance().setScreen(new PlayerSearchScreen(null, player)));
                                            return 1;
                                        })))
                        .executes(ctx -> {
                            ctx.getSource().sendFeedback(Text.translatable("noland.config.title"));
                            return 1;
                        }))
        );

        DiscordPresence.init();
        Runtime.getRuntime().addShutdownHook(new Thread(DiscordPresence::shutdown));

        LOGGER.info("Noland Tier Tagger initialized");
    }

    private static void openSettings(MinecraftClient client) {
        if (client != null) {
            client.setScreen(new ConfigScreen(client.currentScreen));
        }
    }

    private static void openSearch(MinecraftClient client) {
        if (client != null) {
            client.setScreen(new PlayerSearchScreen(client.currentScreen, null));
        }
    }
}
