package com.noland.tiertagger.model;

import net.minecraft.text.Text;

public enum IconStyle {
    SATIR1("satir1", "noland.style.satir1"),
    SATIR2("satir2", "noland.style.satir2"),
    SATIR3("satir3", "noland.style.satir3");

    private final String id;
    private final String translationKey;

    IconStyle(String id, String translationKey) {
        this.id = id;
        this.translationKey = translationKey;
    }

    public String getId() {
        return id;
    }

    public Text getDisplayName() {
        return Text.translatable(translationKey);
    }

    public static IconStyle[] all() {
        return values();
    }

    public IconStyle next() {
        IconStyle[] styles = values();
        return styles[(ordinal() + 1) % styles.length];
    }
}
