package com.noland.tiertagger.model;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public record PlayerTierData(
        String mcName,
        String currentTier,
        Map<String, String> kitTiers,
        Integer points,
        Integer rank,
        String region,
        Map<String, JsonElement> extraFields
) {
    public static Optional<PlayerTierData> fromJson(JsonObject json) {
        if (json == null || json.isJsonNull()) {
            return Optional.empty();
        }

        String name = getString(json, "mcName", "name", "username");
        if (name == null || name.isBlank()) {
            return Optional.empty();
        }

        String currentTier = getString(json, "currentTier", "tier", "overallTier");
        Map<String, String> kitTiers = parseKitTiers(json);
        Integer points = getInt(json, "points", "overallPoints", "score");
        Integer rank = getInt(json, "rank", "overallRank", "place");
        String region = getString(json, "region");

        Map<String, JsonElement> extras = new HashMap<>();
        for (Map.Entry<String, JsonElement> entry : json.entrySet()) {
            String key = entry.getKey();
            if (!key.equals("mcName") && !key.equals("name") && !key.equals("username")
                    && !key.equals("currentTier") && !key.equals("tier") && !key.equals("overallTier")
                    && !key.equals("kitTiers") && !key.equals("kits") && !key.equals("tiers")
                    && !key.equals("points") && !key.equals("overallPoints") && !key.equals("score")
                    && !key.equals("rank") && !key.equals("overallRank") && !key.equals("place")
                    && !key.equals("region") && !key.equals("_id") && !key.equals("__v")
                    && !key.equals("discordId") && !key.equals("discordName")
                    && !key.equals("testsCompleted") && !key.equals("tierHistory")
                    && !key.equals("updatedAt") && !key.equals("overall_rank")
                    && !key.equals("noland") && !key.equals("gapple")) {
                extras.put(key, entry.getValue());
            }
        }

        return Optional.of(new PlayerTierData(
                name,
                currentTier,
                kitTiers,
                points,
                rank,
                region,
                Collections.unmodifiableMap(extras)
        ));
    }

    private static Map<String, String> parseKitTiers(JsonObject json) {
        Map<String, String> result = new HashMap<>();
        JsonElement kits = firstPresent(json, "kitTiers", "kits", "tiers");
        if (kits != null && kits.isJsonObject()) {
            kits.getAsJsonObject().entrySet().forEach(entry -> {
                if (!entry.getValue().isJsonNull()) {
                    result.put(entry.getKey().toLowerCase(), entry.getValue().getAsString());
                }
            });
        }
        return Collections.unmodifiableMap(result);
    }

    private static JsonElement firstPresent(JsonObject json, String... keys) {
        for (String key : keys) {
            if (json.has(key) && !json.get(key).isJsonNull()) {
                return json.get(key);
            }
        }
        return null;
    }

    private static String getString(JsonObject json, String... keys) {
        JsonElement element = firstPresent(json, keys);
        if (element == null || element.isJsonNull()) {
            return null;
        }
        return element.getAsString();
    }

    private static Integer getInt(JsonObject json, String... keys) {
        JsonElement element = firstPresent(json, keys);
        if (element == null || element.isJsonNull()) {
            return null;
        }
        try {
            if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
                return element.getAsInt();
            }
            return Integer.parseInt(element.getAsString());
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    public String getTierForKit(KitType kit) {
        if (kit == KitType.OVERALL) {
            return currentTier;
        }
        if (kit.getKitTiersKey() != null) {
            String tier = kitTiers.get(kit.getKitTiersKey().toLowerCase());
            if (tier != null && !tier.isBlank()) {
                return tier;
            }
        }
        return null;
    }

    public boolean hasAnyTier() {
        if (currentTier != null && !currentTier.isBlank()) {
            return true;
        }
        return false;
    }
}
