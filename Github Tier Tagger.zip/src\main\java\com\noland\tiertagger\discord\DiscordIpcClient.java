package com.noland.tiertagger.discord;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.noland.tiertagger.NolandTierTaggerClient;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public final class DiscordIpcClient {
    private static final int OP_HANDSHAKE = 0;
    private static final int OP_FRAME = 1;
    private static final int OP_CLOSE = 2;
    private static final int OP_PING = 3;
    private static final int OP_PONG = 4;

    private RandomAccessFile pipe;
    private FileInputStream pipeIn;
    private volatile boolean connected = false;
    private Thread ipcThread;
    private final BlockingQueue<String> sendQueue = new LinkedBlockingQueue<>();
    private volatile long heartbeatInterval = 41250;
    private final Object writeLock = new Object();

    public boolean connect(String appId) {
        for (int i = 0; i < 10; i++) {
            if (tryConnect(appId, i)) return true;
        }
        return false;
    }

    private boolean tryConnect(String appId, int index) {
        try {
            String pipePath;
            if (System.getProperty("os.name").toLowerCase().contains("win")) {
                pipePath = "\\\\.\\pipe\\discord-ipc-" + index;
            } else {
                String xdg = System.getenv("XDG_RUNTIME_DIR");
                if (xdg == null || xdg.isEmpty()) xdg = System.getProperty("java.io.tmpdir");
                pipePath = xdg + "/discord-ipc-" + index;
            }

            NolandTierTaggerClient.LOGGER.info("Trying pipe: {}", pipePath);
            pipe = new RandomAccessFile(pipePath, "rw");

            JsonObject handshake = new JsonObject();
            handshake.addProperty("v", 1);
            handshake.addProperty("client_id", appId);
            writeRaf(handshake.toString(), OP_HANDSHAKE);

            Thread.sleep(500);

            int[] header = readRafHeader();
            int opcode = header[0];
            int length = header[1];

            if (opcode == OP_FRAME && length > 0) {
                byte[] payload = new byte[length];
                pipe.readFully(payload);
                String data = new String(payload, StandardCharsets.UTF_8);
                JsonObject json = JsonParser.parseString(data).getAsJsonObject();
                String evt = json.has("evt") ? json.get("evt").getAsString() : "null";

                if ("READY".equals(evt)) {
                    connected = true;
                    if (json.has("d") && json.get("d").isJsonObject()) {
                        JsonObject d = json.get("d").getAsJsonObject();
                        if (d.has("heartbeat_interval")) {
                            heartbeatInterval = d.get("heartbeat_interval").getAsLong();
                        }
                    }
                    pipeIn = new FileInputStream(pipe.getFD());
                    startIpcThread();
                    NolandTierTaggerClient.LOGGER.info("Connected on pipe {} (heartbeat={}ms)", index, heartbeatInterval);
                    return true;
                }
            }
            pipe.close();
            pipe = null;
            return false;
        } catch (Exception e) {
            NolandTierTaggerClient.LOGGER.warn("Pipe {} failed: {}", index, e.getMessage());
            try { if (pipe != null) pipe.close(); } catch (Exception ignored) {}
            pipe = null;
            return false;
        }
    }

    private void startIpcThread() {
        ipcThread = new Thread(() -> {
            long lastHeartbeat = System.currentTimeMillis();

            while (connected && pipe != null) {
                try {
                    String frame = sendQueue.poll();
                    if (frame != null) {
                        synchronized (writeLock) {
                            writeRaf(frame, OP_FRAME);
                        }
                        NolandTierTaggerClient.LOGGER.info("Sent SET_ACTIVITY");
                    }

                    long now = System.currentTimeMillis();
                    if (now - lastHeartbeat >= heartbeatInterval) {
                        synchronized (writeLock) {
                            writeRaf(String.valueOf(now), OP_PING);
                        }
                        lastHeartbeat = now;
                    }

                    drainPipe();

                    Thread.sleep(50);
                } catch (Exception e) {
                    if (connected) {
                        NolandTierTaggerClient.LOGGER.warn("IPC error: {}", e.getMessage());
                        connected = false;
                    }
                    break;
                }
            }
        }, "Discord IPC");
        ipcThread.setDaemon(true);
        ipcThread.start();
    }

    private void drainPipe() {
        try {
            if (pipeIn == null) return;
            while (pipeIn.available() > 0) {
                byte[] hdr = new byte[8];
                int off = 0;
                while (off < 8) {
                    int r = pipeIn.read(hdr, off, 8 - off);
                    if (r == -1) return;
                    off += r;
                }
                ByteBuffer buf = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN);
                int opcode = buf.getInt();
                int length = buf.getInt();

                byte[] payload = null;
                if (length > 0) {
                    payload = new byte[length];
                    int poff = 0;
                    while (poff < length) {
                        int r = pipeIn.read(payload, poff, length - poff);
                        if (r == -1) break;
                        poff += r;
                    }
                }

                if (opcode == OP_PING) {
                    String ts = payload != null ? new String(payload, StandardCharsets.UTF_8) : "0";
                    synchronized (writeLock) {
                        writeRaf(ts, OP_PONG);
                    }
                    NolandTierTaggerClient.LOGGER.debug("PONG sent");
                } else if (opcode == OP_FRAME && payload != null) {
                    String resp = new String(payload, StandardCharsets.UTF_8);
                    NolandTierTaggerClient.LOGGER.debug("Response: {}", resp.substring(0, Math.min(200, resp.length())));
                } else if (opcode == OP_CLOSE) {
                    connected = false;
                    NolandTierTaggerClient.LOGGER.info("Discord closed");
                }
            }
        } catch (Exception e) {
            NolandTierTaggerClient.LOGGER.debug("Drain error: {}", e.getMessage());
        }
    }

    public void updateActivity(String details, String state, String largeImageKey, String largeImageText, long startTimestamp) {
        if (!connected) return;

        try {
            JsonObject activity = new JsonObject();
            activity.addProperty("type", 0);
            if (details != null) activity.addProperty("details", details);
            if (state != null) activity.addProperty("state", state);

            JsonObject assets = new JsonObject();
            if (largeImageKey != null) assets.addProperty("large_image", largeImageKey);
            if (largeImageText != null) assets.addProperty("large_text", largeImageText);
            activity.add("assets", assets);

            if (startTimestamp > 0) {
                JsonObject timestamps = new JsonObject();
                timestamps.addProperty("start", startTimestamp);
                activity.add("timestamps", timestamps);
            }

            com.google.gson.JsonArray buttons = new com.google.gson.JsonArray();

            JsonObject btn1 = new JsonObject();
            btn1.addProperty("label", "Modu İndir");
            btn1.addProperty("url", "https://modrinth.com/mod/nethtiers");
            buttons.add(btn1);

            JsonObject btn2 = new JsonObject();
            btn2.addProperty("label", "Discord'a Katıl");
            btn2.addProperty("url", "https://discord.gg/3vyakwjgxp");
            buttons.add(btn2);

            activity.add("buttons", buttons);

            JsonObject args = new JsonObject();
            args.addProperty("pid", ProcessHandle.current().pid());
            args.add("activity", activity);

            JsonObject frame = new JsonObject();
            frame.addProperty("cmd", "SET_ACTIVITY");
            frame.addProperty("nonce", UUID.randomUUID().toString());
            frame.add("args", args);

            sendQueue.offer(frame.toString());
            NolandTierTaggerClient.LOGGER.info("Queued: {} / {}", details, state);
        } catch (Exception e) {
            NolandTierTaggerClient.LOGGER.warn("Queue failed: {}", e.getMessage());
        }
    }

    public void clearActivity() {
        if (!connected) return;
        try {
            JsonObject args = new JsonObject();
            args.addProperty("pid", ProcessHandle.current().pid());
            JsonObject frame = new JsonObject();
            frame.addProperty("cmd", "SET_ACTIVITY");
            frame.addProperty("nonce", UUID.randomUUID().toString());
            frame.add("args", args);
            sendQueue.offer(frame.toString());
        } catch (Exception ignored) {}
    }

    public boolean isConnected() {
        return connected;
    }

    public void disconnect() {
        connected = false;
        if (ipcThread != null) { ipcThread.interrupt(); ipcThread = null; }
        try { if (pipe != null) pipe.close(); } catch (Exception ignored) {}
        try { if (pipeIn != null) pipeIn.close(); } catch (Exception ignored) {}
        pipe = null;
        pipeIn = null;
    }

    private int[] readRafHeader() throws IOException {
        byte[] header = new byte[8];
        pipe.readFully(header);
        ByteBuffer buf = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN);
        return new int[]{buf.getInt(), buf.getInt()};
    }

    private void writeRaf(String data, int op) throws IOException {
        byte[] dataBytes = data.getBytes(StandardCharsets.UTF_8);
        ByteBuffer header = ByteBuffer.allocate(8);
        header.order(ByteOrder.LITTLE_ENDIAN);
        header.putInt(op);
        header.putInt(dataBytes.length);
        pipe.write(header.array());
        pipe.write(dataBytes);
    }
}
