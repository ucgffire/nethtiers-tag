package com.noland.tiertagger.cache;

import com.noland.tiertagger.api.TierApiService;
import com.noland.tiertagger.config.ModConfig;
import com.noland.tiertagger.model.PlayerTierData;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public final class TierCache {
    private static final Map<String, PlayerTierData> BY_NAME = new ConcurrentHashMap<>();
    private static final Map<UUID, String> UUID_TO_NAME = new ConcurrentHashMap<>();
    private static volatile long lastFetchTime = 0;
    private static volatile CompletableFuture<Void> currentFetch = null;

    private TierCache() {
    }

    public static void registerPlayer(UUID uuid, String name) {
        if (uuid != null && name != null && !name.isBlank()) {
            UUID_TO_NAME.put(uuid, name);
            ensureDataLoaded();
        }
    }

    public static Optional<PlayerTierData> getByName(String name) {
        if (name == null || name.isBlank()) {
            return Optional.empty();
        }
        ensureDataLoaded();
        return Optional.ofNullable(BY_NAME.get(name.toLowerCase()));
    }

    public static Optional<PlayerTierData> getByUuid(UUID uuid) {
        String name = UUID_TO_NAME.get(uuid);
        if (name == null) {
            return Optional.empty();
        }
        return getByName(name);
    }

    public static CompletableFuture<Optional<PlayerTierData>> searchPlayer(String name) {
        String key = name.toLowerCase();
        PlayerTierData cached = BY_NAME.get(key);
        if (cached != null && !isExpired()) {
            return CompletableFuture.completedFuture(Optional.of(cached));
        }
        return fetchAll().thenApply(v -> Optional.ofNullable(BY_NAME.get(key)));
    }

    private static void ensureDataLoaded() {
        if (!BY_NAME.isEmpty() && !isExpired()) {
            return;
        }
        if (currentFetch != null && !currentFetch.isDone()) {
            return;
        }
        fetchAll();
    }

    private static synchronized CompletableFuture<Void> fetchAll() {
        if (currentFetch != null && !currentFetch.isDone()) {
            return currentFetch;
        }
        if (!BY_NAME.isEmpty() && !isExpired()) {
            return CompletableFuture.completedFuture(null);
        }

        currentFetch = TierApiService.fetchAllPlayersAsync().thenAccept(players -> {
            BY_NAME.clear();
            for (PlayerTierData player : players) {
                BY_NAME.put(player.mcName().toLowerCase(), player);
            }
            lastFetchTime = System.currentTimeMillis();
        });
        return currentFetch;
    }

    private static boolean isExpired() {
        return System.currentTimeMillis() - lastFetchTime > ModConfig.get().cacheDurationMs;
    }

    public static void refresh() {
        lastFetchTime = 0;
        ensureDataLoaded();
    }

    public static void clear() {
        BY_NAME.clear();
        lastFetchTime = 0;
    }
}
