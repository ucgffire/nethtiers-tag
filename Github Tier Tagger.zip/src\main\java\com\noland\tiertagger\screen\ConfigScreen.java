package com.noland.tiertagger.screen;

import com.noland.tiertagger.config.ModConfig;
import com.noland.tiertagger.model.IconStyle;
import com.noland.tiertagger.model.KitType;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ConfigScreen extends Screen {
    private static final int ICON_SIZE = 12;
    private static final int COL_SPACING = ICON_SIZE + 4;
    private static final int SELECTOR_SIZE = 12;
    private static final int GRID_TOP_OFFSET = 134;

    private final Screen parent;
    private final ModConfig config;

    public ConfigScreen(Screen parent) {
        super(Text.translatable("noland.config.title"));
        this.parent = parent;
        this.config = ModConfig.get();
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int y = 28;

        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(config.enabled)
                .build(centerX - 100, y, 200, 20, Text.translatable("noland.config.enabled"), (btn, value) -> {
                    config.enabled = value;
                    ModConfig.save();
                }));
        y += 26;

        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(config.showTab)
                .build(centerX - 100, y, 95, 20, Text.translatable("noland.config.show_tab"), (btn, value) -> {
                    config.showTab = value;
                    ModConfig.save();
                }));
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(config.showNametag)
                .build(centerX + 5, y, 95, 20, Text.translatable("noland.config.show_nametag"), (btn, value) -> {
                    config.showNametag = value;
                    ModConfig.save();
                }));
        y += 24;

        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(config.showChat)
                .build(centerX - 100, y, 95, 20, Text.translatable("noland.config.show_chat"), (btn, value) -> {
                    config.showChat = value;
                    ModConfig.save();
                }));
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(config.showKitName)
                .build(centerX + 5, y, 95, 20, Text.translatable("noland.config.show_kit_name"), (btn, value) -> {
                    config.showKitName = value;
                    ModConfig.save();
                }));

        KitType[] kits = KitType.selectableKits();
        int gridStartX = centerX - (SELECTOR_SIZE + 8 + kits.length * COL_SPACING) / 2 + SELECTOR_SIZE + 8;
        int gridY = GRID_TOP_OFFSET;

        for (IconStyle style : IconStyle.all()) {
            int rowY = gridY + style.ordinal() * (ICON_SIZE + 8);

            this.addDrawableChild(ButtonWidget.builder(Text.empty(), btn -> {
                        config.setIconStyle(style);
                        this.clearAndInit();
                    })
                    .dimensions(gridStartX - SELECTOR_SIZE - 8, rowY, SELECTOR_SIZE, SELECTOR_SIZE)
                    .build());
        }

        int bottomY = gridY + IconStyle.all().length * (ICON_SIZE + 8) + 12;
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("noland.config.search"), btn ->
                        this.client.setScreen(new PlayerSearchScreen(this, null)))
                .dimensions(centerX - 100, bottomY, 200, 20)
                .build());

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), btn -> this.close())
                .dimensions(centerX - 100, this.height - 28, 200, 20)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 12, 0xFFFFFF);

        super.render(context, mouseX, mouseY, delta);

        KitType[] kits = KitType.selectableKits();
        int centerX = this.width / 2;
        int gridStartX = centerX - (SELECTOR_SIZE + 8 + kits.length * COL_SPACING) / 2 + SELECTOR_SIZE + 8;
        int gridY = GRID_TOP_OFFSET;

        for (IconStyle style : IconStyle.all()) {
            int rowY = gridY + style.ordinal() * (ICON_SIZE + 8);
            boolean selectedStyle = config.getIconStyle() == style;

            int selX = gridStartX - SELECTOR_SIZE - 8;
            context.fill(selX, rowY, selX + SELECTOR_SIZE, rowY + SELECTOR_SIZE, 0xFF555555);
            context.drawBorder(selX, rowY, SELECTOR_SIZE, SELECTOR_SIZE, selectedStyle ? 0xFFFFFFFF : 0xFF888888);

            for (int i = 0; i < kits.length; i++) {
                KitType kit = kits[i];
                int kitX = gridStartX + i * COL_SPACING;

                Identifier texId = getTextureId(style, kit);
                if (texId != null) {
                    context.drawTexture(texId, kitX, rowY, ICON_SIZE, ICON_SIZE, 0f, 0f, 64, 64, 64, 64);
                }

                if (config.getSelectedKit() == kit && config.getIconStyle() == style) {
                    context.drawBorder(kitX - 1, rowY - 1, ICON_SIZE + 2, ICON_SIZE + 2, 0xFFFFFFFF);
                }

                if (mouseX >= kitX && mouseX < kitX + ICON_SIZE && mouseY >= rowY && mouseY < rowY + ICON_SIZE) {
                    context.fill(kitX, rowY, kitX + ICON_SIZE, rowY + ICON_SIZE, 0x20FFFFFF);
                }
            }
        }
    }

    static Identifier getTextureId(IconStyle style, KitType kit) {
        String folder = switch (style) {
            case SATIR1 -> "textures/font/gamemodes/satir1";
            case SATIR2 -> "textures/font/gamemodes/satir2";
            case SATIR3 -> "textures/font/gamemodes/satir3";
        };
        String file = switch (kit) {
            case OVERALL -> "vanilla";
            case NETHPOT -> "nethpot";
            case SMP -> "smp";
            case SWORD -> "sword";
            case AXE -> "axe";
            case MACE -> "mace";
            case UHC -> "uhc";
            case DIAPOT -> "pot";
            default -> null;
        };
        if (file == null) return null;
        return Identifier.of("minecraft", folder + "/" + file + ".png");
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            KitType[] kits = KitType.selectableKits();
            int centerX = this.width / 2;
            int gridStartX = centerX - (SELECTOR_SIZE + 8 + kits.length * COL_SPACING) / 2 + SELECTOR_SIZE + 8;
            int gridY = GRID_TOP_OFFSET;

            for (IconStyle style : IconStyle.all()) {
                int rowY = gridY + style.ordinal() * (ICON_SIZE + 8);

                for (int i = 0; i < kits.length; i++) {
                    int kitX = gridStartX + i * COL_SPACING;
                    if (mouseX >= kitX && mouseX < kitX + ICON_SIZE && mouseY >= rowY && mouseY < rowY + ICON_SIZE) {
                        config.setSelectedKit(kits[i]);
                        config.setIconStyle(style);
                        ModConfig.save();
                        return true;
                    }
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void close() {
        ModConfig.save();
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }
}
