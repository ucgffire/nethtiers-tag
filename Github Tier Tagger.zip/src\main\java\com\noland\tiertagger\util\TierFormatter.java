package com.noland.tiertagger.util;

import com.noland.tiertagger.config.ModConfig;
import com.noland.tiertagger.model.IconStyle;
import com.noland.tiertagger.model.KitType;
import com.noland.tiertagger.model.PlayerTierData;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.Optional;
import java.util.UUID;

public final class TierFormatter {
    private static final Identifier FONT_SATIR1 = Identifier.of("minecraft", "gamemodes/satir1");
    private static final Identifier FONT_SATIR2 = Identifier.of("minecraft", "gamemodes/satir2");
    private static final Identifier FONT_SATIR3 = Identifier.of("minecraft", "gamemodes/satir3");

    private TierFormatter() {
    }

    public static Identifier getFontId(IconStyle style) {
        return switch (style) {
            case SATIR1 -> FONT_SATIR1;
            case SATIR2 -> FONT_SATIR2;
            case SATIR3 -> FONT_SATIR3;
        };
    }

    public static Text appendTier(UUID uuid, Text original) {
        ModConfig config = ModConfig.get();
        if (!config.enabled) {
            return original;
        }

        return formatTierForPlayer(uuid, original);
    }

    public static Text formatTierForPlayer(UUID uuid, Text original) {
        return com.noland.tiertagger.cache.TierCache.getByUuid(uuid)
                .flatMap(data -> buildTierPrefix(data, ModConfig.get()))
                .<Text>map(prefix -> Text.empty().append(prefix).append(Text.literal(" ").formatted(Formatting.GRAY)).append(original))
                .orElse(original);
    }

    public static Text formatTierForName(String name, Text original) {
        return com.noland.tiertagger.cache.TierCache.getByName(name)
                .flatMap(data -> buildTierPrefix(data, ModConfig.get()))
                .<Text>map(prefix -> Text.empty().append(prefix).append(Text.literal(" ").formatted(Formatting.GRAY)).append(original))
                .orElse(original);
    }

    public static Optional<Text> buildTierPrefix(PlayerTierData data, ModConfig config) {
        if (data == null || !data.hasAnyTier()) {
            return Optional.empty();
        }

        KitType kit = config.getSelectedKit();
        String tier = data.getTierForKit(kit);
        if (tier == null || tier.isBlank()) {
            return Optional.empty();
        }

        IconStyle style = config.getIconStyle();
        char icon = kit.getIconChar(style);
        Identifier fontId = getFontId(style);

        MutableText iconText = Text.literal(String.valueOf(icon))
                .setStyle(Style.EMPTY.withFont(fontId));

        MutableText prefix = Text.empty()
                .append(iconText)
                .append(Text.literal(" " + tier.toUpperCase()).setStyle(Style.EMPTY.withColor(TierColors.getColor(tier))));
        return Optional.of(prefix);
    }

    public static Text buildProfileLine(String label, String value) {
        return Text.empty()
                .append(Text.literal(label + ": ").formatted(Formatting.GRAY))
                .append(Text.literal(value).formatted(Formatting.WHITE));
    }
}
