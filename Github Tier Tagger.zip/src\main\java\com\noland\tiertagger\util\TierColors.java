package com.noland.tiertagger.util;

import java.util.HashMap;
import java.util.Map;

public final class TierColors {
    private static final Map<String, Integer> COLORS = new HashMap<>();

    static {
        COLORS.put("HT1", 0xFF5555);
        COLORS.put("LT1", 0xFF5555);
        COLORS.put("HT2", 0xFFAA00);
        COLORS.put("LT2", 0xFFAA00);
        COLORS.put("HT3", 0xFFFF55);
        COLORS.put("LT3", 0xFFFF55);
        COLORS.put("HT4", 0x55FF55);
        COLORS.put("LT4", 0x55FF55);
        COLORS.put("HT5", 0x55FFFF);
        COLORS.put("LT5", 0x55FFFF);
    }

    private TierColors() {
    }

    public static int getColor(String tier) {
        if (tier == null) {
            return 0xD3D3D3;
        }
        return COLORS.getOrDefault(tier.toUpperCase(), 0xD3D3D3);
    }
}
