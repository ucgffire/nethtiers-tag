package com.noland.tiertagger.model;

import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public enum KitType {
    OVERALL("overall", "noland.kit.overall", null),
    CRYSTAL("crystal", "noland.kit.crystal", "crystal"),
    NETHPOT("nethpot", "noland.kit.nethpot", "nethpot"),
    SMP("smp", "noland.kit.smp", "smp"),
    SWORD("sword", "noland.kit.sword", "sword"),
    AXE("axe", "noland.kit.axe", "axe"),
    MACE("mace", "noland.kit.mace", "mace"),
    UHC("uhc", "noland.kit.uhc", "uhc"),
    DIAPOT("diapot", "noland.kit.diapot", "pot");

    private final String apiKey;
    private final String translationKey;
    private final String kitTiersKey;

    KitType(String apiKey, String translationKey, String kitTiersKey) {
        this.apiKey = apiKey;
        this.translationKey = translationKey;
        this.kitTiersKey = kitTiersKey;
    }

    public String getApiKey() {
        return apiKey;
    }

    public String getKitTiersKey() {
        return kitTiersKey;
    }

    public char getIconChar(IconStyle style) {
        int base = switch (this) {
            case NETHPOT -> 0x00;
            case UHC -> 0x01;
            case DIAPOT -> 0x02;
            case SMP -> 0x03;
            case SWORD -> 0x04;
            case AXE -> 0x05;
            case MACE -> 0x06;
            case OVERALL -> 0x07;
            default -> -1;
        };
        if (base < 0) return '\0';

        int offset = switch (style) {
            case SATIR1 -> 0xF000;
            case SATIR2 -> 0xF010;
            case SATIR3 -> 0xF020;
        };

        return (char) (offset + base);
    }

    public Text getDisplayName() {
        return Text.translatable(translationKey);
    }

    public String getDisplayNameString() {
        return getDisplayName().getString();
    }

    public ItemStack getIconStack(IconStyle style) {
        return switch (this) {
            case OVERALL -> new ItemStack(Items.NETHER_STAR);
            case CRYSTAL -> new ItemStack(Items.END_CRYSTAL);
            case NETHPOT -> new ItemStack(Items.POTION);
            case SMP -> new ItemStack(Items.PLAYER_HEAD);
            case SWORD -> new ItemStack(Items.DIAMOND_SWORD);
            case AXE -> new ItemStack(Items.DIAMOND_AXE);
            case MACE -> new ItemStack(Items.MACE);
            case UHC -> new ItemStack(Items.GOLDEN_APPLE);
            case DIAPOT -> new ItemStack(Items.POTION);
        };
    }

    public Identifier getTextureId(IconStyle style) {
        String folder = switch (style) {
            case SATIR1 -> "kit";
            case SATIR2 -> "kit2";
            case SATIR3 -> "kit3";
        };
        String filename = switch (this) {
            case OVERALL -> "vanilla.png";
            case CRYSTAL -> null;
            case NETHPOT -> "nethpot.png";
            case SMP -> "smp.png";
            case SWORD -> "sword.png";
            case AXE -> "axe.png";
            case MACE -> "mace.png";
            case UHC -> "uhc.png";
            case DIAPOT -> "pot.png";
        };
        if (filename == null) return null;
        return Identifier.of("noland-tier-tagger", "textures/" + folder + "/" + filename);
    }

    public static KitType[] selectableKits() {
        return new KitType[]{NETHPOT, SMP, SWORD, AXE, MACE, UHC, DIAPOT, OVERALL};
    }

    public static KitType fromApiKey(String key) {
        if (key == null) {
            return OVERALL;
        }
        for (KitType kit : values()) {
            if (kit.apiKey.equalsIgnoreCase(key) || (kit.kitTiersKey != null && kit.kitTiersKey.equalsIgnoreCase(key))) {
                return kit;
            }
        }
        return OVERALL;
    }
}
