package com.noland.tiertagger.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.noland.tiertagger.model.IconStyle;
import com.noland.tiertagger.model.KitType;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File CONFIG_FILE = new File(
            FabricLoader.getInstance().getConfigDir().toFile(),
            "noland-tier-tagger.json"
    );

    private static ModConfig INSTANCE;

    public boolean enabled = true;
    public boolean showTab = true;
    public boolean showNametag = true;
    public boolean showChat = true;
    public boolean showKitName = true;
    public String selectedKit = KitType.OVERALL.getApiKey();
    public String iconStyle = IconStyle.SATIR1.getId();
    public long cacheDurationMs = 5 * 60 * 1000L;

    public static ModConfig get() {
        if (INSTANCE == null) {
            load();
        }
        return INSTANCE;
    }

    public static void load() {
        if (CONFIG_FILE.exists()) {
            try (FileReader reader = new FileReader(CONFIG_FILE)) {
                INSTANCE = GSON.fromJson(reader, ModConfig.class);
            } catch (Exception e) {
                INSTANCE = new ModConfig();
            }
        } else {
            INSTANCE = new ModConfig();
        }
        if (INSTANCE == null) {
            INSTANCE = new ModConfig();
        }
        save();
    }

    public static void save() {
        try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
            GSON.toJson(get(), writer);
        } catch (IOException ignored) {
        }
    }

    public KitType getSelectedKit() {
        return KitType.fromApiKey(selectedKit);
    }

    public void setSelectedKit(KitType kit) {
        this.selectedKit = kit.getApiKey();
        save();
    }

    public IconStyle getIconStyle() {
        for (IconStyle style : IconStyle.all()) {
            if (style.getId().equals(iconStyle)) {
                return style;
            }
        }
        return IconStyle.SATIR1;
    }

    public void setIconStyle(IconStyle style) {
        this.iconStyle = style.getId();
        save();
    }
}
