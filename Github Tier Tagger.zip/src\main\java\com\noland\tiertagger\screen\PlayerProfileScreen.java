package com.noland.tiertagger.screen;

import com.mojang.authlib.GameProfile;
import com.noland.tiertagger.config.ModConfig;
import com.noland.tiertagger.model.IconStyle;
import com.noland.tiertagger.model.KitType;
import com.noland.tiertagger.model.PlayerTierData;
import com.noland.tiertagger.util.SkinUtil;
import com.noland.tiertagger.util.TierColors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class PlayerProfileScreen extends Screen {
    private static final int BODY_W = 64;
    private static final int BODY_H = 128;
    private static final int ICON_SIZE = 12;

    private final Screen parent;
    private final PlayerTierData data;
    private final GameProfile profile;
    private SkinUtil.BodySkin bodySkin;

    public PlayerProfileScreen(Screen parent, PlayerTierData data, GameProfile profile) {
        super(Text.translatable("noland.profile.title"));
        this.parent = parent;
        this.data = data;
        this.profile = profile;
    }

    @Override
    protected void init() {
        bodySkin = SkinUtil.getBodySkin(data.mcName());
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.back"), btn -> close())
                .dimensions(this.width / 2 - 100, this.height - 32, 200, 20)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        int centerX = this.width / 2;
        int bodyX = centerX - 110;
        int bodyY = 36;

        if (bodySkin != null && bodySkin.ready && bodySkin.id != null) {
            context.drawTexture(bodySkin.id, bodyX, bodyY, 0, 0, BODY_W, BODY_H, BODY_W, BODY_H);
        } else {
            context.fill(bodyX, bodyY, bodyX + BODY_W, bodyY + BODY_H, 0xFF444444);
            context.drawCenteredTextWithShadow(this.textRenderer, "?", bodyX + BODY_W / 2, bodyY + BODY_H / 2 - 4, 0xAAAAAA);
        }

        int textX = centerX - 30;
        int y = 40;
        context.drawTextWithShadow(this.textRenderer, data.mcName(), textX, y, 0xFFFFFF);
        y += 14;

        if (data.currentTier() != null && !data.currentTier().isBlank()) {
            Text overall = Text.literal("[" + data.currentTier().toUpperCase() + "]")
                    .styled(s -> s.withColor(TierColors.getColor(data.currentTier())));
            context.drawTextWithShadow(this.textRenderer, overall, textX, y, 0xFFFFFF);
            y += 14;
        }

        if (data.points() != null) {
            context.drawTextWithShadow(this.textRenderer,
                    Text.translatable("noland.profile.points", data.points()), textX, y, 0xCCCCCC);
            y += 14;
        }

        if (data.rank() != null) {
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal("#" + data.rank()), textX, y, 0xFFD700);
            y += 14;
        }

        if (data.region() != null && !data.region().isBlank()) {
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal(data.region()), textX, y, 0xFF55FF);
            y += 18;
        }

        y = 40;
        int rightX = centerX + 30;
        IconStyle style = ModConfig.get().getIconStyle();
        for (KitType kit : KitType.selectableKits()) {
            if (kit == KitType.OVERALL) {
                continue;
            }
            String tier = data.getTierForKit(kit);
            if (tier == null || tier.isBlank()) {
                continue;
            }

            Identifier texId = ConfigScreen.getTextureId(style, kit);
            if (texId != null) {
                context.drawTexture(texId, rightX, y, ICON_SIZE, ICON_SIZE, 0f, 0f, 64, 64, 64, 64);
            }

            context.drawTextWithShadow(this.textRenderer, kit.getDisplayName(), rightX + 16, y + 2, 0xAAAAAA);

            Text tierText = Text.literal(tier.toUpperCase())
                    .styled(s -> s.withColor(TierColors.getColor(tier)));
            context.drawTextWithShadow(this.textRenderer, tierText, rightX + 16, y + 12, 0xFFFFFF);
            y += 20;
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }
}
