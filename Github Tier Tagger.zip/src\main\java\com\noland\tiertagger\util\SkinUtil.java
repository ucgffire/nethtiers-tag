package com.noland.tiertagger.util;

import com.noland.tiertagger.NolandTierTaggerClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public final class SkinUtil {
    private static final String BODY_URL = "https://crafthead.net/body/%s";
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();
    private static final Map<String, BodySkin> CACHE = new ConcurrentHashMap<>();

    private SkinUtil() {
    }

    public static BodySkin getBodySkin(String username) {
        String key = username.toLowerCase();
        BodySkin cached = CACHE.get(key);
        if (cached != null) {
            return cached;
        }
        BodySkin pending = new BodySkin(key);
        CACHE.put(key, pending);
        fetchAsync(key, username);
        return pending;
    }

    private static void fetchAsync(String key, String username) {
        String url = String.format(BODY_URL, username);
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(10))
                .header("User-Agent", "NolandTierTagger/1.0")
                .GET()
                .build();

        CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofByteArray())
                .thenAccept(response -> {
                    if (response.statusCode() != 200) {
                        NolandTierTaggerClient.LOGGER.debug("Skin body fetch failed: {}", response.statusCode());
                        BodySkin cached = CACHE.get(key);
                        if (cached != null) cached.failed = true;
                        return;
                    }
                    try {
                        byte[] bytes = response.body();
                        NativeImage image = NativeImage.read(bytes);
                        Identifier id = Identifier.of("noland-tier-tagger", "skin/" + key);
                        MinecraftClient.getInstance().execute(() -> {
                            MinecraftClient.getInstance().getTextureManager().registerTexture(id, new NativeImageBackedTexture(image));
                            BodySkin cached = CACHE.get(key);
                            if (cached != null) {
                                cached.id = id;
                                cached.ready = true;
                            }
                        });
                    } catch (Exception e) {
                        NolandTierTaggerClient.LOGGER.debug("Failed to process skin: {}", e.getMessage());
                        BodySkin cached = CACHE.get(key);
                        if (cached != null) cached.failed = true;
                    }
                })
                .exceptionally(error -> {
                    NolandTierTaggerClient.LOGGER.debug("Skin download error: {}", error.getMessage());
                    BodySkin cached = CACHE.get(key);
                    if (cached != null) cached.failed = true;
                    return null;
                });
    }

    public static class BodySkin {
        public volatile boolean ready;
        public volatile boolean failed;
        public volatile Identifier id;
        public final String key;

        BodySkin(String key) {
            this.key = key;
        }
    }
}
