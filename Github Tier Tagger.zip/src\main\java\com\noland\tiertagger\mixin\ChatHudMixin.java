package com.noland.tiertagger.mixin;

import com.noland.tiertagger.cache.TierCache;
import com.noland.tiertagger.config.ModConfig;
import com.noland.tiertagger.util.TierFormatter;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Mixin(ChatHud.class)
public class ChatHudMixin {
    private static final Pattern CHAT_NAME_PATTERN = Pattern.compile("^<([a-zA-Z0-9_]{3,16})>");

    @ModifyVariable(method = "addMessage(Lnet/minecraft/text/Text;)V", at = @At("HEAD"), argsOnly = true)
    private Text noland$modifyChatMessage(Text message) {
        ModConfig config = ModConfig.get();
        if (!config.enabled || !config.showChat || message == null) {
            return message;
        }

        String plain = message.getString();
        Matcher matcher = CHAT_NAME_PATTERN.matcher(plain);
        if (!matcher.find()) {
            return message;
        }

        String playerName = matcher.group(1);
        TierCache.registerPlayer(null, playerName);
        return TierFormatter.formatTierForName(playerName, message);
    }
}
